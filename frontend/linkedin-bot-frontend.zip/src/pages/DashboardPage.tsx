import React, { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import { api } from '../api';
import { getUser } from '../auth';

interface QueuedPost {
  id: string;
  content: string;
  hashtags: string | null;
  scheduledAt: string | null;
  status: string;
}

const DashboardPage: React.FC = () => {
  const [health, setHealth] = useState<string | null>(null);
  const [healthLoading, setHealthLoading] = useState(false);

  const [content, setContent] = useState('');
  const [scheduledAt, setScheduledAt] = useState('');
  const [createLoading, setCreateLoading] = useState(false);
  const [createMessage, setCreateMessage] = useState<string | null>(null);

  const [queue, setQueue] = useState<QueuedPost[]>([]);
  const [queueLoading, setQueueLoading] = useState(false);

  const user = getUser();

  const loadQueue = async () => {
    setQueueLoading(true);
    try {
      const res = await api.get('/posts/queue');
      setQueue(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setQueueLoading(false);
    }
  };

  useEffect(() => {
    loadQueue();
  }, []);

  const checkHealth = async () => {
    setHealthLoading(true);
    try {
      const res = await api.get('/health');
      setHealth(res.data.ok ? 'OK' : 'Not OK');
    } catch (err) {
      console.error(err);
      setHealth('Error');
    } finally {
      setHealthLoading(false);
    }
  };

  const handleConnectLinkedIn = async () => {
    try {
      const res = await api.get('/linkedin/connect');
      const url = res.data.url;
      window.location.href = url;
    } catch (err) {
      console.error(err);
      alert('Failed to get LinkedIn connect URL');
    }
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateLoading(true);
    setCreateMessage(null);
    try {
      const body: any = {
        content,
        source: 'MANUAL'
      };
      if (scheduledAt) {
        body.scheduledAt = new Date(scheduledAt).toISOString();
      }
      await api.post('/posts', body);
      setCreateMessage('Post created successfully');
      setContent('');
      setScheduledAt('');
      await loadQueue();
    } catch (err) {
      console.error(err);
      setCreateMessage('Failed to create post');
    } finally {
      setCreateLoading(false);
    }
  };

  return (
    <div className="page-root">
      <Navbar />
      <main className="main">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">
          Welcome {user?.email ? `, ${user.email}` : ''}. Configure your LinkedIn bot and manage posts.
        </p>

        <section className="card-grid">
          <div className="card">
            <h2>API Health</h2>
            <p>Check if your backend is running correctly.</p>
            <button className="btn btn-secondary" onClick={checkHealth} disabled={healthLoading}>
              {healthLoading ? 'Checking...' : 'Check Health'}
            </button>
            {health && <p className="tag">Status: {health}</p>}
          </div>

          <div className="card">
            <h2>LinkedIn Connection</h2>
            <p>
              Connect your LinkedIn account so the bot can publish posts on your behalf
              using official LinkedIn APIs.
            </p>
            <button className="btn btn-primary" onClick={handleConnectLinkedIn}>
              Connect LinkedIn
            </button>
            <p className="hint">
              After authorizing on LinkedIn, you may need a simple callback wiring on the backend
              to bind the connection to your user automatically.
            </p>
          </div>
        </section>

        <section className="card">
          <h2>Create a Post</h2>
          <p>
            Quickly create a manual post to be queued or saved as draft. Later you can wire Google Sheets
            and AI generators into this pipeline.
          </p>
          <form className="form-inline" onSubmit={handleCreatePost}>
            <label className="form-label">
              Content
              <textarea
                className="form-textarea"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                required
              />
            </label>
            <label className="form-label">
              Scheduled At (optional)
              <input
                type="datetime-local"
                className="form-input"
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
              />
            </label>
            <button className="btn btn-primary" type="submit" disabled={createLoading}>
              {createLoading ? 'Creating...' : 'Create Post'}
            </button>
            {createMessage && <p className="hint">{createMessage}</p>}
          </form>
        </section>

        <section className="card">
          <h2>Queued Posts</h2>
          <button className="btn btn-outline" onClick={loadQueue} disabled={queueLoading}>
            {queueLoading ? 'Refreshing...' : 'Refresh'}
          </button>
          {queue.length === 0 && !queueLoading && (
            <p className="hint">No queued posts yet.</p>
          )}
          {queue.length > 0 && (
            <table className="table">
              <thead>
                <tr>
                  <th>Content</th>
                  <th>Scheduled At</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {queue.map((p) => (
                  <tr key={p.id}>
                    <td>
                      {p.content.length > 80 ? `${p.content.slice(0, 80)}…` : p.content}
                    </td>
                    <td>{p.scheduledAt ? new Date(p.scheduledAt).toLocaleString() : '-'}</td>
                    <td>{p.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </main>
    </div>
  );
};

export default DashboardPage;
