import Parser from 'rss-parser';
import axios from 'axios';
import { TOPIC_DIVERSITY_CONFIG } from '../config/topicDiversityConfig';

export interface Trend {
  title: string;
  link: string;
  pubDate: string;
  source: string;
  niche?: string;
  searchQuery?: string;
  summary?: string;
  keyPoints?: string[];
}

export type TrendFetchInput = {
  niche: string;
  queries?: string[];
  exclusions?: string[];
  sources?: string[];
  customFeeds?: string[];
  customLinks?: string[];
  customRedditFeeds?: string[];
  limit?: number;
};

export class TrendsService {
  private parser: Parser;

  constructor() {
    this.parser = new Parser();
  }

  async fetchTrends(
    niche: string,
    sources: string[] = ['google'],
    customFeeds: string[] = [],
    customLinks: string[] = [],
    customRedditFeeds: string[] = [],
    limit: number = 10,
  ): Promise<Trend[]> {
    return this.fetchTrendsWithInput({
      niche,
      sources,
      customFeeds,
      customLinks,
      customRedditFeeds,
      limit,
    });
  }

  async fetchTrendsWithInput(input: TrendFetchInput): Promise<Trend[]> {
    const {
      niche,
      queries = [niche],
      sources = ['google'],
      customFeeds = [],
      customLinks = [],
      customRedditFeeds = [],
      limit = 10,
    } = input;

    const candidateTarget = Math.min(
      TOPIC_DIVERSITY_CONFIG.maxFetchedCandidates,
      Math.max(limit * TOPIC_DIVERSITY_CONFIG.candidateMultiplier, 24),
    );

    const activeQueries = [...new Set(queries.map((q) => q.trim()).filter(Boolean))]
      .slice(0, TOPIC_DIVERSITY_CONFIG.maxExpansionQueries);

    if (activeQueries.length === 0) activeQueries.push(niche);

    const sourceCount = Math.max(1, sources.length + (customFeeds.length ? 1 : 0));
    const perQueryPerSource = Math.max(2, Math.ceil(candidateTarget / (activeQueries.length * sourceCount)));

    const fetchJobs: Array<() => Promise<Trend[]>> = [];

    for (let qi = 0; qi < activeQueries.length; qi++) {
      const query = activeQueries[qi];
      for (const source of sources) {
        fetchJobs.push(() => this.fetchFromSource(source, query, niche, perQueryPerSource, query));
      }
    }

    if (customFeeds.length) {
      for (const url of customFeeds.slice(0, 5)) {
        fetchJobs.push(() => this.fetchCustomRssTrends(url, perQueryPerSource).then((items) =>
          items.map((t) => ({ ...t, niche, searchQuery: niche })),
        ));
      }
    }

    if (customRedditFeeds.length) {
      for (const url of customRedditFeeds.slice(0, 3)) {
        fetchJobs.push(() => this.fetchRedditJsonTrends(url, perQueryPerSource).then((items) =>
          items.map((t) => ({ ...t, niche, searchQuery: niche })),
        ));
      }
    }

    if (customLinks.length) {
      fetchJobs.push(() => this.fetchCustomTrends(customLinks, Math.min(customLinks.length, perQueryPerSource)).then((items) =>
        items.map((t) => ({ ...t, niche, searchQuery: niche })),
      ));
    }

    const results: Trend[] = [];
    const concurrency = TOPIC_DIVERSITY_CONFIG.trendFetchConcurrency;
    for (let i = 0; i < fetchJobs.length; i += concurrency) {
      const batch = fetchJobs.slice(i, i + concurrency);
      const settled = await Promise.allSettled(batch.map((fn) => fn()));
      for (const s of settled) {
        if (s.status === 'fulfilled') results.push(...s.value);
      }
    }

    const deduped = this.dedupeTrends(results);
    const sorted = deduped.sort((a, b) => this.safeTime(b.pubDate) - this.safeTime(a.pubDate));
    return sorted.slice(0, candidateTarget);
  }

  private async fetchFromSource(
    source: string,
    query: string,
    niche: string,
    limit: number,
    searchQuery: string,
  ): Promise<Trend[]> {
    let items: Trend[] = [];
    switch (source.toLowerCase()) {
      case 'reddit':
        items = await this.fetchRedditTrends(query, limit);
        break;
      case 'medium':
        items = await this.fetchMediumTrends(query, limit);
        break;
      case 'google':
        items = await this.fetchGoogleTrends(query, limit);
        break;
      case 'linkedin':
        items = await this.fetchGoogleSearchTrends(query, 'linkedin.com', limit);
        break;
      case 'quora':
        items = await this.fetchGoogleSearchTrends(query, 'quora.com', limit);
        break;
      default:
        items = [];
    }
    return items.map((t) => ({ ...t, niche, searchQuery }));
  }

  async fetchRedditTrends(niche: string, limit: number = 5): Promise<Trend[]> {
    const sanitizedNiche = niche.replace(/\s+/g, '');
    const url = `https://www.reddit.com/r/${sanitizedNiche}/top.json?limit=${Math.min(
      100,
      Math.max(1, limit),
    )}&t=day`;

    let results = await this.fetchRedditJsonTrends(url, limit);

    if (results.length === 0 && niche.includes(' ')) {
      const firstWord = niche.split(' ')[0];
      const fallbackUrl = `https://www.reddit.com/r/${firstWord}/top.json?limit=${Math.min(
        100,
        Math.max(1, limit),
      )}&t=day`;
      results = await this.fetchRedditJsonTrends(fallbackUrl, limit);
    }

    return results.slice(0, limit);
  }

  async fetchRedditJsonTrends(url: string, limit: number = 5): Promise<Trend[]> {
    try {
      const { data } = await axios.get(url, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          Accept: 'application/json',
        },
        timeout: 12000,
      });

      if (!data?.data?.children) return [];

      return data.data.children.slice(0, limit).map((child: any) => ({
        title: child.data.title,
        link: `https://www.reddit.com${child.data.permalink}`,
        pubDate: new Date(child.data.created_utc * 1000).toISOString(),
        source: `Reddit (${child.data.subreddit_name_prefixed})`,
      }));
    } catch (error: any) {
      if (error.response?.status !== 404) {
        console.error(`Error fetching Reddit JSON trends from ${url}:`, error.message);
      }
      return [];
    }
  }

  async fetchMediumTrends(niche: string, limit: number = 5): Promise<Trend[]> {
    try {
      const url = `https://medium.com/feed/tag/${encodeURIComponent(niche)}`;
      const feed = await this.parser.parseURL(url);

      return (feed.items || []).slice(0, limit).map((item) => ({
        title: item.title || 'No Title',
        link: item.link || '',
        pubDate: item.pubDate || '',
        source: 'Medium',
      }));
    } catch (error) {
      console.error(`Error fetching Medium trends for ${niche}:`, error);
      return [];
    }
  }

  async fetchGoogleSearchTrends(niche: string, site?: string, limit: number = 5): Promise<Trend[]> {
    try {
      const query = site ? `${niche} site:${site}` : niche;
      const encodedQuery = encodeURIComponent(query);
      const url = `https://news.google.com/rss/search?q=${encodedQuery}&hl=en-US&gl=US&ceid=US:en`;

      const feed = await this.parser.parseURL(url);

      return (feed.items || []).slice(0, limit).map((item) => ({
        title: item.title || 'No Title',
        link: item.link || '',
        pubDate: item.pubDate || '',
        source: site ? `Google News (${site})` : 'Google News',
      }));
    } catch (error) {
      console.error(`Error fetching Google trends for ${niche} (site: ${site}):`, error);
      return [];
    }
  }

  async fetchGoogleTrends(topic: string, limit: number = 5): Promise<Trend[]> {
    return this.fetchGoogleSearchTrends(topic, undefined, limit);
  }

  async fetchCustomRssTrends(url: string, limit: number = 5): Promise<Trend[]> {
    try {
      const resp = await axios.get(url, {
        timeout: 10000,
        headers: { 'User-Agent': 'Mozilla/5.0' },
        responseType: 'text',
        validateStatus: () => true,
      });

      const contentType = (resp.headers['content-type'] || '').toLowerCase();
      const text = typeof resp.data === 'string' ? resp.data : '';

      const looksLikeXml =
        text.trimStart().startsWith('<?xml')
        || text.trimStart().startsWith('<rss')
        || text.trimStart().startsWith('<feed');
      const isXmlType = contentType.includes('xml') || contentType.includes('rss') || contentType.includes('atom');

      if (!looksLikeXml && !isXmlType) {
        console.warn(`[RSS SKIP] Not an RSS/Atom feed: ${url} (content-type: ${contentType || 'unknown'})`);
        return [];
      }

      const feed = await this.parser.parseString(text);

      return (feed.items || []).slice(0, limit).map((item) => ({
        title: item.title || 'No Title',
        link: item.link || '',
        pubDate: item.pubDate || '',
        source: `RSS (${new URL(url).hostname})`,
      }));
    } catch (error: any) {
      console.error(`Error fetching custom RSS feed ${url}:`, error.message || error);
      return [];
    }
  }

  async fetchCustomTrends(links: string[], limit: number = 5): Promise<Trend[]> {
    return links.slice(0, limit).map((link) => {
      let title = link;
      try {
        const urlObj = new URL(link);

        const keyword = urlObj.searchParams.get('keywords') || urlObj.searchParams.get('q') || urlObj.searchParams.get('tag');

        if (keyword) {
          title = keyword.charAt(0).toUpperCase() + keyword.slice(1);
        } else {
          const segments = urlObj.pathname.split('/').filter((s) => s.length > 0);
          const lastSegment = segments.pop();
          if (lastSegment) {
            title = lastSegment.replace(/[-_]/g, ' ');
            title = title.charAt(0).toUpperCase() + title.slice(1);
          }
        }
      } catch {}

      return {
        title,
        link,
        pubDate: new Date().toISOString(),
        source: 'Custom Link',
      };
    });
  }

  private safeTime(d: string): number {
    const t = Date.parse(d || '');
    return Number.isFinite(t) ? t : 0;
  }

  private dedupeTrends(trends: Trend[]): Trend[] {
    const map = new Map<string, Trend>();
    for (const t of trends) {
      const key = `${(t.title || '').trim().toLowerCase()}|${(t.link || '').trim().toLowerCase()}`;
      if (!map.has(key)) map.set(key, t);
    }
    return Array.from(map.values());
  }
}
