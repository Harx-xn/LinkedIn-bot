import { TOPIC_DIVERSITY_CONFIG } from '../config/topicDiversityConfig';
import type { TrendCandidate } from './generationTypes';
import { jaccardSimilarity } from './ghostwriterTextUtils';

export const LOW_VALUE_TITLE_PATTERNS: Array<{ pattern: RegExp; code: string }> = [
  { pattern: /\bhiring\b/i, code: 'job_listing' },
  { pattern: /\bjob(s)?\b/i, code: 'job_listing' },
  { pattern: /\bintern(ship)?\b/i, code: 'internship' },
  { pattern: /\bunpaid\b/i, code: 'unpaid_work' },
  { pattern: /\bapply now\b/i, code: 'apply_now' },
  { pattern: /\bdevelopment company\b/i, code: 'agency_page' },
  { pattern: /\bbest .* company\b/i, code: 'company_directory' },
  { pattern: /\btop \d+ .* companies\b/i, code: 'company_directory' },
  { pattern: /\bhow much does .* cost\b/i, code: 'pricing_page' },
  { pattern: /\bcost in [a-z ]+\b/i, code: 'pricing_page' },
  { pattern: /\bpress release\b/i, code: 'press_release' },
  { pattern: /\bstrengthens position\b/i, code: 'pr_announcement' },
  { pattern: /\bagency services?\b/i, code: 'agency_page' },
  { pattern: /\brecruitment\b/i, code: 'job_listing' },
  { pattern: /\bvacancy\b/i, code: 'job_listing' },
  { pattern: /\bseo services\b/i, code: 'promotional_service' },
];

const FILLER_WORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'for', 'to', 'in', 'on', 'of', 'with', 'by',
  'how', 'what', 'why', 'when', 'your', 'our', 'their', 'this', 'that', 'from',
  'guide', 'best', 'top', 'new', 'latest', 'update', 'updates',
]);

const SOURCE_QUALITY: Record<string, number> = {
  medium: 0.78,
  reddit: 0.62,
  google: 0.82,
  rss: 0.75,
  custom: 0.55,
};

export type LowValueRejection = {
  trend: TrendCandidate;
  code: string;
};

export function normalizeTrendTitle(title: string): string {
  return title
    .toLowerCase()
    .replace(/\b20\d{2}\b/g, ' ')
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 1 && !FILLER_WORDS.has(w))
    .join(' ')
    .trim();
}

export function trendTitleSimilarity(a: string, b: string): number {
  const na = normalizeTrendTitle(a);
  const nb = normalizeTrendTitle(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1;
  return jaccardSimilarity(na, nb);
}

export function escapeLiteralPhrase(phrase: string): string {
  return phrase.trim().toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function matchesExclusion(title: string, exclusions: string[]): string | null {
  const lower = title.toLowerCase();
  for (const raw of exclusions) {
    const phrase = raw.trim().toLowerCase();
    if (phrase.length < 2) continue;
    if (lower.includes(phrase)) return `exclusion:${phrase}`;
  }
  return null;
}

export function rejectLowValueTrend(
  trend: TrendCandidate,
  exclusions: string[] = [],
): { rejected: boolean; code?: string } {
  const topic = trend.topic.trim();
  if (!topic) return { rejected: true, code: 'empty_title' };

  for (const { pattern, code } of LOW_VALUE_TITLE_PATTERNS) {
    if (pattern.test(topic)) return { rejected: true, code };
  }

  const exclusion = matchesExclusion(topic, exclusions);
  if (exclusion) return { rejected: true, code: exclusion };

  if (/linkedin\.com\/jobs|indeed\.com|glassdoor/i.test(trend.link ?? '')) {
    return { rejected: true, code: 'job_board_source' };
  }

  return { rejected: false };
}

export function filterLowValueTrends(
  trends: TrendCandidate[],
  exclusions: string[] = [],
): { accepted: TrendCandidate[]; rejected: LowValueRejection[] } {
  const accepted: TrendCandidate[] = [];
  const rejected: LowValueRejection[] = [];
  for (const trend of trends) {
    const result = rejectLowValueTrend(trend, exclusions);
    if (result.rejected) {
      rejected.push({ trend, code: result.code ?? 'low_value' });
    } else {
      accepted.push(trend);
    }
  }
  return { accepted, rejected };
}

function sourceQualityScore(source?: string): number {
  const s = (source ?? '').toLowerCase();
  if (s.includes('medium')) return SOURCE_QUALITY.medium;
  if (s.includes('reddit')) return SOURCE_QUALITY.reddit;
  if (s.includes('google')) return SOURCE_QUALITY.google;
  if (s.includes('rss')) return SOURCE_QUALITY.rss;
  if (s.includes('custom')) return SOURCE_QUALITY.custom;
  return 0.65;
}

function parsePubDate(value?: string | Date | null): number {
  if (!value) return 0;
  const t = Date.parse(String(value));
  return Number.isFinite(t) ? t : 0;
}

function metadataCompleteness(trend: TrendCandidate): number {
  let score = 0;
  if (trend.link) score += 0.4;
  if (trend.source) score += 0.3;
  if (trend.publishedAt) score += 0.3;
  return score;
}

function isPromotionalSource(source?: string): boolean {
  return /\b(custom link|agency|services)\b/i.test(source ?? '');
}

export function pickPreferredTrend(a: TrendCandidate, b: TrendCandidate): TrendCandidate {
  const sa = sourceQualityScore(a.source);
  const sb = sourceQualityScore(b.source);
  if (sa !== sb) return sa > sb ? a : b;

  const da = parsePubDate(a.publishedAt);
  const db = parsePubDate(b.publishedAt);
  if (da !== db) return da > db ? a : b;

  const ma = metadataCompleteness(a);
  const mb = metadataCompleteness(b);
  if (ma !== mb) return ma > mb ? a : b;

  const pa = isPromotionalSource(a.source) ? 0 : 1;
  const pb = isPromotionalSource(b.source) ? 0 : 1;
  if (pa !== pb) return pa > pb ? a : b;

  return a;
}

export function exactDedupeTrends(trends: TrendCandidate[]): TrendCandidate[] {
  const map = new Map<string, TrendCandidate>();
  for (const t of trends) {
    const key = `${t.topic.trim().toLowerCase()}|${(t.link ?? '').trim().toLowerCase()}`;
    const existing = map.get(key);
    map.set(key, existing ? pickPreferredTrend(existing, t) : t);
  }
  return Array.from(map.values());
}

export function nearDedupeTrends(
  trends: TrendCandidate[],
  threshold: number = TOPIC_DIVERSITY_CONFIG.titleDuplicateThreshold,
): { kept: TrendCandidate[]; removed: number } {
  const kept: TrendCandidate[] = [];
  let removed = 0;

  for (const trend of trends) {
    let duplicateIdx = -1;
    for (let i = 0; i < kept.length; i++) {
      if (trendTitleSimilarity(trend.topic, kept[i].topic) >= threshold) {
        duplicateIdx = i;
        break;
      }
    }
    if (duplicateIdx >= 0) {
      kept[duplicateIdx] = pickPreferredTrend(kept[duplicateIdx], trend);
      removed++;
    } else {
      kept.push(trend);
    }
  }

  return { kept, removed };
}

export function dedupeTrendCandidates(trends: TrendCandidate[]): TrendCandidate[] {
  const exact = exactDedupeTrends(trends);
  return nearDedupeTrends(exact).kept;
}
