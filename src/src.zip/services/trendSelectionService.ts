import { TOPIC_DIVERSITY_CONFIG } from '../config/topicDiversityConfig';
import type {
  AuthorContext,
  NicheExpansionPlan,
  RankedTrendCandidate,
  TopicFingerprint,
  TrendCandidate,
} from './generationTypes';
import { TopicFingerprintService } from './topicFingerprintService';
import { loadRecentTopicHistory, type TopicHistoryRow } from './topicHistoryService';
import { evaluateTopicNovelty } from './topicNoveltyService';
import {
  dedupeTrendCandidates,
  filterLowValueTrends,
  normalizeTrendTitle,
} from './trendTitleUtils';
import type { Trend } from './trendsService';
import { jaccardSimilarity } from './ghostwriterTextUtils';

export type TrendSelectionStats = {
  rawCount: number;
  rejectedLowValue: number;
  deduplicated: number;
  fingerprinted: number;
  blockedByHistory: number;
  selected: number;
  evergreenFilled: number;
};

function toTrendCandidate(trend: Trend, niche?: string): TrendCandidate {
  return {
    topic: trend.title,
    link: trend.link,
    source: trend.source,
    publishedAt: trend.pubDate,
    niche: trend.niche ?? niche,
    searchQuery: trend.searchQuery,
    summary: trend.summary,
    keyPoints: trend.keyPoints,
  };
}

function relevanceScore(trend: TrendCandidate, author: AuthorContext, plan: NicheExpansionPlan): number {
  const topic = trend.topic.toLowerCase();
  let score = 50;
  const niches = author.niches ?? [plan.niche];
  for (const niche of niches) {
    if (topic.includes(niche.toLowerCase())) score += 20;
  }
  for (const sub of plan.subtopics) {
    if (topic.includes(sub.toLowerCase())) score += 8;
  }
  const authorOverlap = jaccardSimilarity(topic, author.description ?? '');
  score += Math.round(authorOverlap * 20);
  return Math.max(0, Math.min(100, score));
}

function sourceQualityScore(source?: string): number {
  const s = (source ?? '').toLowerCase();
  if (s.includes('google')) return 85;
  if (s.includes('medium')) return 78;
  if (s.includes('rss')) return 75;
  if (s.includes('reddit')) return 62;
  if (s.includes('custom')) return 50;
  return 65;
}

function recencyScore(publishedAt?: string | Date | null): number {
  if (!publishedAt) return 40;
  const t = Date.parse(String(publishedAt));
  if (!Number.isFinite(t)) return 40;
  const days = (Date.now() - t) / (1000 * 60 * 60 * 24);
  if (days <= 1) return 100;
  if (days <= 7) return 85;
  if (days <= 30) return 65;
  if (days <= 90) return 45;
  return 25;
}

function technicalDepthScore(topic: string): number {
  if (/\b(how to|guide|architecture|pattern|research|study|analysis|implementation|framework|api|database|queue|deploy)\b/i.test(topic)) {
    return 75;
  }
  return 45;
}

function rankCandidate(
  trend: TrendCandidate,
  fingerprint: TopicFingerprint,
  author: AuthorContext,
  plan: NicheExpansionPlan,
  history: TopicHistoryRow[],
): RankedTrendCandidate {
  const novelty = evaluateTopicNovelty(fingerprint, history);
  const relevance = relevanceScore(trend, author, plan);
  const sourceQ = sourceQualityScore(trend.source);
  const recency = recencyScore(trend.publishedAt);
  const depth = technicalDepthScore(trend.topic);
  const totalScore =
    relevance * 0.30
    + sourceQ * 0.15
    + recency * 0.15
    + depth * 0.15
    + novelty.score * 0.25;

  return {
    trend: { ...trend, fingerprint },
    fingerprint,
    relevanceScore: relevance,
    sourceQualityScore: sourceQ,
    recencyScore: recency,
    technicalDepthScore: depth,
    noveltyScore: novelty.score,
    totalScore,
    novelty,
  };
}

export function selectDiverseCandidates(
  ranked: RankedTrendCandidate[],
  limit: number,
  maxPerCluster = TOPIC_DIVERSITY_CONFIG.maxPerClusterInBatch,
): RankedTrendCandidate[] {
  const allowed = ranked.filter((r) => r.novelty.allowed);
  const sorted = [...allowed].sort((a, b) => b.totalScore - a.totalScore);
  const selected: RankedTrendCandidate[] = [];
  const clusterCounts = new Map<string, number>();

  for (const candidate of sorted) {
    const cluster = candidate.fingerprint.topicCluster;
    const count = clusterCounts.get(cluster) ?? 0;
    if (count >= maxPerCluster) continue;

    const tooSimilar = selected.some((s) => {
      const sim = jaccardSimilarity(
        normalizeTrendTitle(s.fingerprint.coreClaim),
        normalizeTrendTitle(candidate.fingerprint.coreClaim),
      );
      return sim >= TOPIC_DIVERSITY_CONFIG.currentBatchSemanticThreshold;
    });
    if (tooSimilar) continue;

    selected.push(candidate);
    clusterCounts.set(cluster, count + 1);
    if (selected.length >= limit) break;
  }

  if (selected.length < limit) {
    for (const candidate of sorted) {
      if (selected.includes(candidate)) continue;
      if (!candidate.novelty.allowed) continue;
      selected.push(candidate);
      if (selected.length >= limit) break;
    }
  }

  return selected;
}

export async function processTrendCandidates(params: {
  userId: string;
  rawTrends: Trend[];
  niche: string;
  plan: NicheExpansionPlan;
  author: AuthorContext;
  limit: number;
  fingerprintService: TopicFingerprintService;
  history?: TopicHistoryRow[];
}): Promise<{ selected: RankedTrendCandidate[]; stats: TrendSelectionStats }> {
  const history = params.history ?? await loadRecentTopicHistory(params.userId);
  let candidates = params.rawTrends.map((t) => toTrendCandidate(t, params.niche));

  const { accepted, rejected } = filterLowValueTrends(candidates, params.plan.exclusions);
  const beforeDedupe = accepted.length;
  candidates = dedupeTrendCandidates(accepted);
  const deduplicated = beforeDedupe - candidates.length;

  const preRanked = candidates
    .map((t) => ({
      trend: t,
      preScore:
        relevanceScore(t, params.author, params.plan)
        + sourceQualityScore(t.source)
        + recencyScore(t.publishedAt),
    }))
    .sort((a, b) => b.preScore - a.preScore)
    .slice(0, TOPIC_DIVERSITY_CONFIG.maxFingerprintCandidates)
    .map((x) => x.trend);

  await params.fingerprintService.fingerprintTrends(
    preRanked,
    TOPIC_DIVERSITY_CONFIG.fingerprintConcurrency,
  );

  const ranked: RankedTrendCandidate[] = [];
  let blockedByHistory = 0;

  for (const trend of preRanked) {
    const fp = params.fingerprintService.getCached(trend)
      ?? (await params.fingerprintService.fingerprintTrend(trend));
    const item = rankCandidate(trend, fp, params.author, params.plan, history);
    if (!item.novelty.allowed) blockedByHistory++;
    ranked.push(item);

    console.log('[trend-selection] candidate evaluated', {
      userId: params.userId,
      title: trend.topic.slice(0, 80),
      cluster: fp.topicCluster,
      relevanceScore: item.relevanceScore,
      noveltyScore: item.noveltyScore,
      totalScore: Math.round(item.totalScore),
      noveltyReasons: item.novelty.reasons,
    });
  }

  const selected = selectDiverseCandidates(ranked, params.limit);

  return {
    selected,
    stats: {
      rawCount: params.rawTrends.length,
      rejectedLowValue: rejected.length,
      deduplicated,
      fingerprinted: preRanked.length,
      blockedByHistory,
      selected: selected.length,
      evergreenFilled: 0,
    },
  };
}
