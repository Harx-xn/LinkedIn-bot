import { ContentService } from './contentService';
import type { AuthorContext, BatchPostPlan, RankedTrendCandidate, TrendCandidate } from './generationTypes';
import { summarizeBatchPlan, buildTopicDiverseBatchPlan } from './ghostwriterBatchPlanner';
import type { Trend } from './trendsService';
import {
  generateSlotPost as generateSlotPostImpl,
  generateSlotPostUntilSuccess as generateSlotPostUntilSuccessImpl,
  type GeneratedSlotResult,
} from './ghostwriterGenerationService';
import { TrendOrchestrationService } from './trendOrchestrationService';
import { validatePlanTopicDiversity } from './trendDiversityService';

export type { GeneratedSlotResult };

export type GhostwriterBotConfig = {
  tone?: string | null;
  description?: string | null;
  niches: string[];
  backgroundImageUrl?: string | null;
  customLinks?: string | null;
  contactInfo?: string | null;
  websiteUrl?: string | null;
  includeContactInfo?: boolean;
  includeWebsiteLink?: boolean;
};

function toTrendCandidates(trends: Trend[], niche?: string): TrendCandidate[] {
  return trends.map((t) => ({
    topic: t.title,
    link: t.link,
    source: t.source,
    publishedAt: t.pubDate,
    niche: t.niche ?? niche,
    searchQuery: t.searchQuery,
    summary: t.summary,
    keyPoints: t.keyPoints,
    fingerprint: undefined,
  }));
}

/** @deprecated Use prepareBatchContextV2 for topic-diverse selection */
export async function prepareBatchContext(
  nicheTrendsMap: Record<string, Trend[]>,
  niches: string[],
  config: GhostwriterBotConfig,
  slotCount: number,
) {
  const author: AuthorContext = {
    description: config.description || '',
    tone: config.tone || 'Professional',
    niches,
  };

  const allCandidates: TrendCandidate[] = [];
  for (const niche of niches) {
    allCandidates.push(...toTrendCandidates(nicheTrendsMap[niche] ?? [], niche));
  }

  return { author, eligible: allCandidates.slice(0, slotCount), ranked: [] as RankedTrendCandidate[] };
}

export async function prepareBatchContextV2(params: {
  userId: string;
  niches: string[];
  config: GhostwriterBotConfig;
  slotCount: number;
  sources: string[];
  customFeeds: string[];
  customLinks: string[];
  customRedditFeeds: string[];
  openaiApiKey?: string | null;
}) {
  const author: AuthorContext = {
    description: params.config.description || '',
    tone: params.config.tone || 'Professional',
    niches: params.niches,
  };

  const orchestrator = new TrendOrchestrationService(params.openaiApiKey);
  const pool = await orchestrator.buildTrendPoolForBatch({
    userId: params.userId,
    niches: params.niches,
    author,
    sources: params.sources,
    customFeeds: params.customFeeds,
    customLinks: params.customLinks,
    customRedditFeeds: params.customRedditFeeds,
    slotCount: params.slotCount,
  });

  return { author, eligible: pool.eligible, ranked: pool.ranked, stats: pool.stats };
}

export async function generateSlotPost(
  contentService: ContentService,
  plan: BatchPostPlan,
  trend: TrendCandidate | null,
  author: AuthorContext,
  config: GhostwriterBotConfig,
  acceptedBodies: string[],
  provider: 'OPENAI' | 'GEMINI' = 'OPENAI',
  options?: {
    batchFingerprints?: import('./generationTypes').TopicFingerprint[];
    recentTopicHistory?: import('./topicHistoryService').TopicHistoryRow[];
  },
): Promise<GeneratedSlotResult> {
  return generateSlotPostImpl(
    contentService,
    plan,
    trend,
    author,
    config,
    acceptedBodies,
    provider,
    options,
  );
}

export async function generateSlotPostUntilSuccess(
  contentService: ContentService,
  plan: BatchPostPlan,
  trend: TrendCandidate | null,
  author: AuthorContext,
  config: GhostwriterBotConfig,
  acceptedBodies: string[],
  provider: 'OPENAI' | 'GEMINI' = 'OPENAI',
  options?: {
    batchFingerprints?: import('./generationTypes').TopicFingerprint[];
    recentTopicHistory?: import('./topicHistoryService').TopicHistoryRow[];
  },
) {
  return generateSlotPostUntilSuccessImpl(
    contentService,
    plan,
    trend,
    author,
    config,
    acceptedBodies,
    provider,
    options,
  );
}

export async function planBatchForGeneration(
  contentService: ContentService,
  eligible: TrendCandidate[],
  author: AuthorContext,
  count: number,
  provider: 'OPENAI' | 'GEMINI' = 'OPENAI',
  ranked?: RankedTrendCandidate[],
) {
  if (ranked?.length) {
    const plan = buildTopicDiverseBatchPlan(ranked.slice(0, count), count);
    const diversityIssues = validatePlanTopicDiversity(plan);
    if (diversityIssues.length) {
      console.warn('[ghostwriter] batch plan diversity warnings', { issues: diversityIssues });
    }
    console.log('[ghostwriter] batch plan', summarizeBatchPlan(plan, author));
    return plan;
  }

  const plan = await contentService.planBatch(eligible, author, count, provider);
  console.log('[ghostwriter] batch plan', summarizeBatchPlan(plan, author));
  return plan;
}
