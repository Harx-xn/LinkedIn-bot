import type { AuthorContext, NicheExpansionPlan, RankedTrendCandidate, TrendCandidate } from './generationTypes';
import { NicheExpansionService } from './nicheExpansionService';
import { TopicFingerprintService } from './topicFingerprintService';
import { processTrendCandidates, type TrendSelectionStats } from './trendSelectionService';
import { fillEvergreenIfNeeded, rankedToTrendCandidates } from './trendDiversityService';
import { TrendsService } from './trendsService';

export type OrchestratedTrendPool = {
  eligible: TrendCandidate[];
  ranked: RankedTrendCandidate[];
  expansionPlans: NicheExpansionPlan[];
  stats: TrendSelectionStats;
};

export class TrendOrchestrationService {
  private trendsService: TrendsService;
  private nicheExpansion: NicheExpansionService;
  private fingerprintService: TopicFingerprintService;

  constructor(openaiApiKey?: string | null) {
    this.trendsService = new TrendsService();
    this.nicheExpansion = new NicheExpansionService(openaiApiKey);
    this.fingerprintService = new TopicFingerprintService(openaiApiKey);
  }

  async buildTrendPoolForBatch(params: {
    userId: string;
    niches: string[];
    author: AuthorContext;
    sources: string[];
    customFeeds: string[];
    customLinks: string[];
    customRedditFeeds: string[];
    slotCount: number;
  }): Promise<OrchestratedTrendPool> {
    const perNicheLimit = Math.max(
      8,
      Math.ceil((params.slotCount * 4) / Math.max(1, params.niches.length)),
    );

    const expansionPlans: NicheExpansionPlan[] = [];
    const allRanked: RankedTrendCandidate[] = [];
    const aggregateStats: TrendSelectionStats = {
      rawCount: 0,
      rejectedLowValue: 0,
      deduplicated: 0,
      fingerprinted: 0,
      blockedByHistory: 0,
      selected: 0,
      evergreenFilled: 0,
    };

    for (const niche of params.niches) {
      const plan = await this.nicheExpansion.getOrCreatePlan(params.userId, niche);
      expansionPlans.push(plan);

      const rawTrends = await this.trendsService.fetchTrendsWithInput({
        niche,
        queries: plan.queries,
        exclusions: plan.exclusions,
        sources: params.sources,
        customFeeds: params.customFeeds,
        customLinks: params.customLinks,
        customRedditFeeds: params.customRedditFeeds,
        limit: perNicheLimit,
      });

      const { selected, stats } = await processTrendCandidates({
        userId: params.userId,
        rawTrends,
        niche,
        plan,
        author: { ...params.author, niches: params.niches },
        limit: perNicheLimit,
        fingerprintService: this.fingerprintService,
      });

      allRanked.push(...selected);
      aggregateStats.rawCount += stats.rawCount;
      aggregateStats.rejectedLowValue += stats.rejectedLowValue;
      aggregateStats.deduplicated += stats.deduplicated;
      aggregateStats.fingerprinted += stats.fingerprinted;
      aggregateStats.blockedByHistory += stats.blockedByHistory;
    }

    allRanked.sort((a, b) => b.totalScore - a.totalScore);
    let ranked = allRanked.slice(0, params.slotCount);

    if (ranked.length < params.slotCount) {
      const { extra, filled } = await fillEvergreenIfNeeded(
        params.userId,
        params.author,
        expansionPlans,
        ranked,
        params.slotCount - ranked.length,
      );
      aggregateStats.evergreenFilled = filled;

      for (const t of extra) {
        const fp = t.fingerprint ?? (await this.fingerprintService.fingerprintTrend(t));
        ranked.push({
          trend: { ...t, fingerprint: fp },
          fingerprint: fp,
          relevanceScore: 55,
          sourceQualityScore: 50,
          recencyScore: 40,
          technicalDepthScore: 50,
          noveltyScore: 70,
          totalScore: 55,
          novelty: { allowed: true, score: 70, reasons: ['evergreen_fallback'] },
        });
      }
      ranked = ranked.slice(0, params.slotCount);
    }

    aggregateStats.selected = ranked.length;

    console.log('[trend-selection] selected batch topics', {
      userId: params.userId,
      topics: ranked.map((item) => ({
        title: item.trend.topic,
        cluster: item.fingerprint.topicCluster,
        normalizedTopic: item.fingerprint.normalizedTopic,
        coreClaim: item.fingerprint.coreClaim,
      })),
      stats: aggregateStats,
    });

    return {
      eligible: rankedToTrendCandidates(ranked),
      ranked,
      expansionPlans,
      stats: aggregateStats,
    };
  }
}
