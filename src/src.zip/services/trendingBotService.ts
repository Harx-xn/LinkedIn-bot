import { TrendsService, Trend } from "./trendsService";
import { ContentService } from "./contentService";
import { ImageService } from "./imageService";
import { prisma } from "../prismaClient";
import { decryptSecret, decryptSecretArray } from "./secretCrypto";
import {
  buildBatchScheduleSlots,
  calculateBatchSlotCount,
  parsePostingSchedule,
  validateScheduleForGeneration,
  BatchScheduleError,
} from "./batchScheduleService";
import {
  isImageGenerationAllowed,
  recordImageGeneration,
} from "./planEntitlementService";
import {
  generateSlotPostUntilSuccess,
  planBatchForGeneration,
  prepareBatchContextV2,
  type GhostwriterBotConfig,
} from "./ghostwriterPipeline";
import { evaluateTopicCombination } from "./ghostwriterQualityService";
import { buildDeterministicBatchPlan } from "./ghostwriterBatchPlanner";
import type { TopicFingerprint, TrendCandidate } from "./generationTypes";
import { NicheExpansionService } from "./nicheExpansionService";
import { TrendOrchestrationService } from "./trendOrchestrationService";
import { rejectLowValueTrend } from "./trendTitleUtils";
import { createGeneratedTopicHistory, loadRecentTopicHistory } from "./topicHistoryService";
import { fingerprintFromBody } from "./topicFingerprintService";

export class TrendingBotService {
  private trendsService: TrendsService;
  private imageService: ImageService;

  constructor() {
    this.trendsService = new TrendsService();
    this.imageService = new ImageService();
  }

  // Resolve the region a user belongs to (used to stamp generated posts).
  private async getUserRegionId(userId: string): Promise<string | null> {
    const u = await prisma.user.findUnique({
      where: { id: userId },
      select: { regionId: true },
    });
    return u?.regionId ?? null;
  }

  // Build a ContentService using the user's region AI keys (env fallback).
  private async getContentService(userId: string): Promise<ContentService> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { region: { select: { openaiApiKey: true, geminiApiKeys: true } } },
    });

    const geminiApiKeys = decryptSecretArray(user?.region?.geminiApiKeys);
    const openaiApiKey = decryptSecret(user?.region?.openaiApiKey);

    return new ContentService({
      openaiApiKey,
      geminiApiKeys,
    });
  }

  async runBot(dryRun: boolean = false) {
    console.log("Starting Trending Bot...");

    // 1. Fetch all enabled specific configurations
    const configs = await prisma.botConfig.findMany({
      where: { isEnabled: true },
    });

    if (configs.length === 0) {
      console.log("No enabled bot configurations found.");
      return;
    }

    for (const config of configs) {
      console.log(`Processing config for user ${config.userId}`);

      const contentService = await this.getContentService(config.userId);
      const regionId = config.regionId ?? (await this.getUserRegionId(config.userId));

      let niches: string[] = [];
      try {
        if (config.niches) {
          const parsed = JSON.parse(config.niches);
          niches = Array.isArray(parsed) ? parsed : [config.niches];
        } else {
          niches = ["Technology"];
        }
      } catch (e) {
        console.warn("Error parsing niches:", e);
        niches = ["Technology"];
      }

      console.log(`User Niches: ${niches.join(", ")}`);

      for (const niche of niches) {
        console.log(`--- Processing Niche: ${niche} ---`);
        try {
          const sources = config.sources
            ? JSON.parse(config.sources)
            : ["google"];
          let customRssFeeds: string[] = [];
          try {
            customRssFeeds = config.customRssFeeds
              ? JSON.parse(config.customRssFeeds)
              : [];
          } catch {}
          let customLinks: string[] = [];
          try {
            customLinks = (config as any).customLinks
              ? JSON.parse((config as any).customLinks)
              : [];
          } catch {}
          let customRedditFeeds: string[] = [];
          try {
            customRedditFeeds = (config as any).customRedditFeeds
              ? JSON.parse((config as any).customRedditFeeds)
              : [];
          } catch {}

          const trends = await this.trendsService.fetchTrends(
            niche,
            sources,
            customRssFeeds,
            customLinks,
            customRedditFeeds,
          );
          if (trends.length === 0) {
            console.log(`No trends found for ${niche}`);
            continue;
          }

          const botConfig: GhostwriterBotConfig = {
            tone: config.tone,
            description: config.description,
            niches: [niche],
            backgroundImageUrl: config.backgroundImageUrl,
            customLinks: config.customLinks,
            contactInfo: config.contactInfo,
            websiteUrl: config.websiteUrl,
            includeContactInfo: config.includeContactInfo,
            includeWebsiteLink: config.includeWebsiteLink,
          };

          const author = {
            description: config.description || '',
            tone: config.tone || 'Professional',
            niches: [niche],
          };

          const openaiKey = decryptSecret(
            (await prisma.user.findUnique({
              where: { id: config.userId },
              select: { region: { select: { openaiApiKey: true } } },
            }))?.region?.openaiApiKey,
          );
          const orchestrator = new TrendOrchestrationService(openaiKey);
          const pool = await orchestrator.buildTrendPoolForBatch({
            userId: config.userId,
            niches: [niche],
            author,
            sources,
            customFeeds: customRssFeeds,
            customLinks,
            customRedditFeeds,
            slotCount: 1,
          });
          const selectedRanked = pool.ranked[0];
          const selectedTrend: Trend | null = selectedRanked
            ? {
                title: selectedRanked.trend.topic,
                link: selectedRanked.trend.link ?? '',
                pubDate: String(selectedRanked.trend.publishedAt ?? ''),
                source: selectedRanked.trend.source ?? '',
                niche,
              }
            : null;

          if (!selectedTrend) {
            console.log(`No eligible trends for ${niche}. Skipping.`);
            continue;
          }

          const provider: "OPENAI" = "OPENAI";
          const plan = buildDeterministicBatchPlan(
            [{ topic: selectedTrend.title, link: selectedTrend.link, source: selectedTrend.source, fingerprint: selectedRanked?.fingerprint }],
            1,
          )[0];
          if (selectedRanked?.fingerprint) {
            plan.topicCluster = selectedRanked.fingerprint.topicCluster;
            plan.normalizedTopic = selectedRanked.fingerprint.normalizedTopic;
            plan.coreClaim = selectedRanked.fingerprint.coreClaim;
            plan.mechanismFocus = selectedRanked.fingerprint.mechanisms;
          }

          const history = await loadRecentTopicHistory(config.userId);
          const result = await generateSlotPostUntilSuccess(
            contentService,
            plan,
            { topic: selectedTrend.title, link: selectedTrend.link, source: selectedTrend.source, fingerprint: selectedRanked?.fingerprint },
            author,
            botConfig,
            [],
            provider,
            { batchFingerprints: [], recentTopicHistory: history },
          );

          if (dryRun) {
            console.log(`[DRY RUN] Generated for ${config.userId}:\n${result.finalized.content}`);
            continue;
          }

          let imagePath: string | null = null;
          if (await isImageGenerationAllowed(config.userId) && result.imageContent?.mode !== 'none') {
            try {
              const imagePayload = result.imageContent ?? null;
              imagePath = await this.imageService.createTopicImage(
                imagePayload?.headline ?? result.finalized.headline,
                config.backgroundImageUrl || undefined,
                {
                  headline: imagePayload?.headline ?? result.finalized.headline,
                  subheadline: imagePayload?.supportingText,
                  bulletPoints: (imagePayload?.bulletPoints ?? []).slice(0, 3),
                  mode: imagePayload?.mode ?? 'single_insight',
                },
              );
              await recordImageGeneration(config.userId);
            } catch (e) {
              console.error("Image generation failed:", e);
            }
          }

          const created = await prisma.post.create({
            data: {
              userId: config.userId,
              regionId,
              content: result.finalized.content,
              source: "AI_TRENDING",
              status: "REVIEW",
              hashtags: result.finalized.hashtags,
              mediaUrl: imagePath,
            },
          });
          const fp = selectedRanked?.fingerprint
            ?? fingerprintFromBody(result.finalized.body, selectedTrend.title, plan.angle);
          await createGeneratedTopicHistory({
            userId: config.userId,
            postId: created.id,
            sourceTitle: selectedTrend.title,
            fingerprint: fp,
            angle: plan.angle,
          });
          console.log(`Draft created for user ${config.userId}`);
        } catch (error) {
          console.error(`Error processing niche ${niche}:`, error);
        }
      }
    }
  }

  async generateNow(userId: string, daysWindow: number, jobId?: string) {
    const config = await prisma.botConfig.findUnique({ where: { userId } });
    if (!config || !config.isEnabled) return;

    console.log(
      `Generating batch for user ${userId}, window: ${daysWindow} days`,
    );

    const contentService = await this.getContentService(userId);

    let niches: string[] = [];
    try {
      niches = JSON.parse(config.niches);
    } catch {
      niches = ["Technology"];
    }

    const sources = config.sources ? JSON.parse(config.sources) : ["google"];
    let customRssFeeds: string[] = [];
    try {
      customRssFeeds = config.customRssFeeds
        ? JSON.parse(config.customRssFeeds)
        : [];
    } catch {}
    let customLinks: string[] = [];
    try {
      customLinks = (config as any).customLinks
        ? JSON.parse((config as any).customLinks)
        : [];
    } catch {}
    let customRedditFeeds: string[] = [];
    try {
      customRedditFeeds = (config as any).customRedditFeeds
        ? JSON.parse((config as any).customRedditFeeds)
        : [];
    } catch {}

    let schedule;
    try {
      schedule = parsePostingSchedule(config.postingSchedule);
      validateScheduleForGeneration(schedule);
    } catch (err) {
      if (err instanceof BatchScheduleError) {
        throw err;
      }
      schedule = parsePostingSchedule(null);
    }

    const totalPosts = calculateBatchSlotCount(config.postsPerWeek, daysWindow);
    const slots = buildBatchScheduleSlots({
      count: totalPosts,
      schedule,
      startDate: new Date(),
    });
    if (jobId) {
      await prisma.botGenerationJob.update({
        where: { id: jobId },
        data: { totalSlots: slots.length, completedSlots: 0 },
      });
    }
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { region: { select: { openaiApiKey: true } } },
    });
    const openaiKey = decryptSecret(user?.region?.openaiApiKey);

    const botConfig: GhostwriterBotConfig = {
      tone: config.tone,
      description: config.description,
      niches,
      backgroundImageUrl: config.backgroundImageUrl,
      customLinks: config.customLinks,
      contactInfo: config.contactInfo,
      websiteUrl: config.websiteUrl,
      includeContactInfo: config.includeContactInfo,
      includeWebsiteLink: config.includeWebsiteLink,
    };

    const { author, eligible, ranked } = await prepareBatchContextV2({
      userId,
      niches,
      config: botConfig,
      slotCount: slots.length,
      sources,
      customFeeds: customRssFeeds,
      customLinks,
      customRedditFeeds,
      openaiApiKey: openaiKey,
    });

    const provider: "OPENAI" = "OPENAI";
    const batchPlan = await planBatchForGeneration(
      contentService,
      eligible,
      author,
      slots.length,
      provider,
      ranked,
    );

    const acceptedBodies: string[] = [];
    const batchFingerprints: TopicFingerprint[] = [];
    const history = await loadRecentTopicHistory(userId);
    let postsCreated = 0;

    for (let slotIndex = 0; slotIndex < slots.length; slotIndex++) {
      const currentSlot = slots[slotIndex];
      const plan = batchPlan[slotIndex];
      const trend: TrendCandidate | null = eligible[slotIndex] ?? null;

      const shouldMix = niches.length > 1 && (slotIndex + 1) % 4 === 0;
      if (shouldMix && eligible.length >= 2) {
        const t1 = eligible[slotIndex];
        const t2 = eligible[(slotIndex + 1) % eligible.length];
        const combine = evaluateTopicCombination(t1.topic, t2.topic, author);
        if (!combine.canCombine) {
          console.warn('[ghostwriter] skipping weak mixed slot', { reason: combine.reason });
        }
      }

      const result = await generateSlotPostUntilSuccess(
        contentService,
        plan,
        trend,
        author,
        botConfig,
        acceptedBodies,
        provider,
        { batchFingerprints, recentTopicHistory: history },
      );

      await this.saveReviewPost(
        userId,
        result.finalized,
        result.imageContent,
        currentSlot,
        botConfig,
        {
          batchId: jobId,
          sourceTitle: trend?.topic ?? plan.sourceTopic ?? undefined,
          fingerprint: trend?.fingerprint
            ?? (plan.normalizedTopic
              ? {
                  normalizedTopic: plan.normalizedTopic,
                  topicCluster: plan.topicCluster ?? 'other',
                  coreClaim: plan.coreClaim ?? plan.normalizedTopic,
                  entities: [],
                  mechanisms: plan.mechanismFocus ?? [],
                }
              : fingerprintFromBody(result.finalized.body, trend?.topic, plan.angle)),
          angle: plan.angle,
        },
      );
      acceptedBodies.push(result.finalized.body);
      const postFp = fingerprintFromBody(result.finalized.body, trend?.topic ?? plan.sourceTopic ?? undefined, plan.angle);
      batchFingerprints.push(postFp);
      postsCreated++;

      if (jobId) {
        await prisma.botGenerationJob.update({
          where: { id: jobId },
          data: { completedSlots: { increment: 1 } },
        });
      }
    }

    console.log(`Batch complete. Created ${postsCreated} posts.`);
  }

  private async saveReviewPost(
    userId: string,
    finalized: {
      content: string;
      hashtags: string;
      headline: string;
      subheadline: string;
      bulletPoints: string[];
      body: string;
    },
    imageContent: { mode: string; headline: string; supportingText?: string; bulletPoints?: string[] } | null,
    scheduledAt: Date,
    config: GhostwriterBotConfig,
    topicMeta?: {
      batchId?: string;
      sourceTitle?: string;
      fingerprint: TopicFingerprint;
      angle?: import('./generationTypes').PostAngle;
    },
  ) {
    let mediaUrl: string | null = null;
    if (await isImageGenerationAllowed(userId) && imageContent?.mode !== 'none') {
      try {
        mediaUrl = await this.imageService.createTopicImage(
          imageContent?.headline ?? finalized.headline,
          config.backgroundImageUrl ?? undefined,
          {
            headline: imageContent?.headline ?? finalized.headline,
            subheadline: imageContent?.supportingText,
            bulletPoints: (imageContent?.bulletPoints ?? []).slice(0, 3),
            mode: (imageContent?.mode as 'single_insight' | 'checklist' | 'comparison' | 'quote' | 'none') ?? 'single_insight',
          },
        );
        await recordImageGeneration(userId);
      } catch (e) {
        console.error("Image generation failed:", e);
      }
    }

    const linkedInAccount = await prisma.linkedInAccount.findFirst({
      where: { userId },
      select: { id: true },
    });

    const regionId = await this.getUserRegionId(userId);

    const created = await prisma.post.create({
      data: {
        userId,
        regionId,
        content: finalized.content,
        status: "REVIEW",
        scheduledAt,
        source: "AI",
        mediaUrl,
        hashtags: finalized.hashtags,
        linkedinAccountId: linkedInAccount?.id ?? null,
      },
    });

    if (topicMeta?.fingerprint) {
      await createGeneratedTopicHistory({
        userId,
        postId: created.id,
        batchId: topicMeta.batchId,
        sourceTitle: topicMeta.sourceTitle,
        fingerprint: topicMeta.fingerprint,
        angle: topicMeta.angle,
      });
    }

    console.log(`Created review post with proposed slot ${scheduledAt.toISOString()}`);
    return created;
  }

  async previewTrends(userId: string): Promise<Trend[]> {
    const config = await prisma.botConfig.findUnique({
      where: { userId },
    });
  
    if (!config) {
      console.warn("[previewTrends] Bot config not found", { userId });
      return [];
    }
  
    let niches: string[] = [];
  
    try {
      const parsedNiches = config.niches
        ? JSON.parse(config.niches)
        : ["Technology"];
  
      niches = Array.isArray(parsedNiches)
        ? parsedNiches
            .filter((value): value is string => typeof value === "string")
            .map((value) => value.trim())
            .filter(Boolean)
        : typeof parsedNiches === "string" && parsedNiches.trim()
          ? [parsedNiches.trim()]
          : ["Technology"];
    } catch (error) {
      console.error("[previewTrends] Failed to parse niches", {
        userId,
        rawNiches: config.niches,
        error,
      });
  
      niches = ["Technology"];
    }
  
    if (niches.length === 0) {
      niches = ["Technology"];
    }
  
    let sources: string[] = ["google"];
  
    try {
      const parsedSources = config.sources
        ? JSON.parse(config.sources)
        : ["google"];
  
      sources = Array.isArray(parsedSources)
        ? parsedSources.filter(
            (value): value is string =>
              typeof value === "string" && value.trim().length > 0,
          )
        : ["google"];
    } catch (error) {
      console.error("[previewTrends] Failed to parse sources", {
        userId,
        rawSources: config.sources,
        error,
      });
    }
  
    const parseStringArray = (
      rawValue: string | null | undefined,
      fieldName: string,
    ): string[] => {
      if (!rawValue) return [];
  
      try {
        const parsed = JSON.parse(rawValue);
  
        if (!Array.isArray(parsed)) {
          console.warn(`[previewTrends] ${fieldName} is not an array`, {
            userId,
            value: parsed,
          });
          return [];
        }
  
        return parsed.filter(
          (value): value is string =>
            typeof value === "string" && value.trim().length > 0,
        );
      } catch (error) {
        console.error(`[previewTrends] Failed to parse ${fieldName}`, {
          userId,
          rawValue,
          error,
        });
        return [];
      }
    };
  
    const customRssFeeds = parseStringArray(
      config.customRssFeeds,
      "customRssFeeds",
    );
  
    const customLinks = parseStringArray(
      (config as any).customLinks,
      "customLinks",
    );
  
    const customRedditFeeds = parseStringArray(
      (config as any).customRedditFeeds,
      "customRedditFeeds",
    );
  
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        regionId: true,
        region: {
          select: {
            openaiApiKey: true,
          },
        },
      },
    });
  
    const openaiKey = decryptSecret(user?.region?.openaiApiKey);
  
    if (!openaiKey) {
      console.warn(
        "[previewTrends] No OpenAI key found; using original niches as search queries",
        {
          userId,
          regionId: user?.regionId,
        },
      );
    }
  
    const expansion = openaiKey
      ? new NicheExpansionService(openaiKey)
      : null;
  
    const allTrends: Trend[] = [];
  
    for (const niche of niches) {
      let queries = [niche];
      let exclusions: string[] = [];
  
      if (expansion) {
        try {
          const plan = await expansion.getOrCreatePlan(userId, niche);
  
          if (Array.isArray(plan.queries) && plan.queries.length > 0) {
            queries = plan.queries;
          }
  
          if (Array.isArray(plan.exclusions)) {
            exclusions = plan.exclusions;
          }
  
          console.log("[previewTrends] Expansion plan created", {
            userId,
            niche,
            queries,
            exclusions,
          });
        } catch (error) {
          console.error(
            "[previewTrends] Niche expansion failed; falling back to original niche",
            {
              userId,
              niche,
              error,
            },
          );
        }
      }
  
      try {
        const nicheTrends =
          await this.trendsService.fetchTrendsWithInput({
            niche,
            queries,
            exclusions,
            sources,
            customFeeds: customRssFeeds,
            customLinks,
            customRedditFeeds,
            limit: 20,
          });
  
        console.log("[previewTrends] Trends fetched", {
          userId,
          niche,
          queries,
          count: nicheTrends.length,
        });
  
        allTrends.push(...nicheTrends);
      } catch (error) {
        console.error("[previewTrends] Trend fetching failed", {
          userId,
          niche,
          queries,
          sources,
          error,
        });
      }
    }
  
    console.log("[previewTrends] Total raw trends", {
      userId,
      count: allTrends.length,
    });
  
    const filtered: Trend[] = [];
  
    for (const trend of allTrends) {
      const rejection = rejectLowValueTrend(
        {
          topic: trend.title,
          link: trend.link,
          source: trend.source,
        },
        [],
      );
  if (rejection.rejected) {
  console.log("[previewTrends] Trend rejected", {
    title: trend.title,
    code: rejection.code,
  });

  continue;
}
  
      filtered.push(trend);
    }
  
    const uniqueTrends = Array.from(
      new Map(
        filtered.map((trend) => [
          trend.title.trim().toLowerCase(),
          trend,
        ]),
      ).values(),
    );
  
    console.log("[previewTrends] Preview completed", {
      userId,
      rawCount: allTrends.length,
      acceptedCount: filtered.length,
      uniqueCount: uniqueTrends.length,
    });
  
    return uniqueTrends.slice(0, 20);
  }
}
