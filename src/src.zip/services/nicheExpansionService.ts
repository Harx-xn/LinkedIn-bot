import OpenAI from 'openai';
import { z } from 'zod';
import { prisma } from '../prismaClient';
import { NICHE_EXPANSION_PLAN_VERSION } from '../config/topicDiversityConfig';
import type { NicheExpansionPlan } from './generationTypes';

export const NICHE_EXPANSION_SYSTEM_PROMPT = `
You create structured content-discovery plans from user-provided niches.

Given a niche:
- infer the broad domain
- create narrower subtopics when useful
- generate diverse search queries suitable for Google News, RSS, Reddit, Medium, and general content discovery
- keep all queries relevant to the niche
- never assume the niche is technology, medical, legal, financial, or commercial unless appropriate
- avoid jobs, hiring, internships, agencies, directories, promotional services, pricing pages, and press-release content
- return valid JSON only
`;

const nicheExpansionSchema = z.object({
  niche: z.string().min(1).max(120),
  domain: z.string().min(2).max(80),
  confidence: z.number().min(0).max(1),
  subtopics: z.array(z.string().min(2).max(120)).min(3).max(10),
  queries: z.array(z.string().min(5).max(180)).min(4).max(15),
  exclusions: z.array(z.string().min(2).max(120)).max(20),
});

const NICHE_EXPANSION_OPENAI_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['niche', 'domain', 'confidence', 'subtopics', 'queries', 'exclusions'],
  properties: {
    niche: { type: 'string', minLength: 1, maxLength: 120 },
    domain: { type: 'string', minLength: 2, maxLength: 80 },
    confidence: { type: 'number', minimum: 0, maximum: 1 },
    subtopics: { type: 'array', items: { type: 'string', minLength: 2, maxLength: 120 }, minItems: 3, maxItems: 10 },
    queries: { type: 'array', items: { type: 'string', minLength: 5, maxLength: 180 }, minItems: 4, maxItems: 15 },
    exclusions: { type: 'array', items: { type: 'string', minLength: 2, maxLength: 120 }, maxItems: 20 },
  },
} as const;

const JOB_QUERY_PATTERNS = [
  /\bhiring\b/i,
  /\bjob(s)?\b/i,
  /\bintern(ship)?\b/i,
  /\bagency\b/i,
  /\bpricing\b/i,
  /\bcost\b/i,
  /\bpress release\b/i,
];

const DOMAIN_MISMATCH_PAIRS: Array<{ nicheHint: RegExp; badPhrase: RegExp }> = [
  { nicheHint: /\b(diseases?|health|medical|clinical)\b/i, badPhrase: /\b(developer tools?|saas|software deployment|api design)\b/i },
  { nicheHint: /\b(real estate|property|housing)\b/i, badPhrase: /\b(clinical|disease|vaccine|diagnosis)\b/i },
  { nicheHint: /\b(fitness|workout|exercise)\b/i, badPhrase: /\b(legal compliance|tax law|mortgage)\b/i },
];

export function normalizeNicheKey(niche: string): string {
  return niche.trim().toLowerCase().replace(/\s+/g, ' ');
}

export function buildFallbackQueries(niche: string): string[] {
  return [
    `"${niche}" latest developments`,
    `"${niche}" recent research`,
    `"${niche}" industry trends`,
    `"${niche}" expert analysis`,
    `"${niche}" innovations`,
    `"${niche}" challenges and solutions`,
  ];
}

export function buildFallbackExpansionPlan(niche: string): NicheExpansionPlan {
  return {
    niche,
    domain: niche,
    confidence: 0.4,
    subtopics: [niche],
    queries: buildFallbackQueries(niche),
    exclusions: ['hiring', 'jobs', 'internship', 'agency', 'press release', 'how much does', 'best company'],
    version: NICHE_EXPANSION_PLAN_VERSION,
    generatedAt: new Date(),
  };
}

function tokenize(text: string): string[] {
  return text.toLowerCase().split(/\s+/).filter((t) => t.length > 2);
}

function querySimilarity(a: string, b: string): number {
  const ta = new Set(tokenize(a));
  const tb = new Set(tokenize(b));
  const inter = [...ta].filter((x) => tb.has(x)).length;
  const union = new Set([...ta, ...tb]).size;
  return union === 0 ? 0 : inter / union;
}

function hasDomainMismatch(niche: string, query: string): boolean {
  for (const pair of DOMAIN_MISMATCH_PAIRS) {
    if (pair.nicheHint.test(niche) && pair.badPhrase.test(query)) return true;
  }
  return false;
}

export function validateExpansionQuery(
  query: string,
  niche: string,
  subtopics: string[],
  seen: string[],
): { valid: boolean; reason?: string } {
  const trimmed = query.trim();
  if (trimmed.length < 5 || trimmed.length > 180) {
    return { valid: false, reason: 'length' };
  }

  const lower = trimmed.toLowerCase();
  const nicheLower = niche.toLowerCase();
  const referencesNiche = lower.includes(nicheLower)
    || subtopics.some((s) => lower.includes(s.toLowerCase()));
  if (!referencesNiche) return { valid: false, reason: 'niche_mismatch' };

  for (const re of JOB_QUERY_PATTERNS) {
    if (re.test(trimmed)) return { valid: false, reason: 'promotional_query' };
  }

  if (hasDomainMismatch(niche, trimmed)) return { valid: false, reason: 'domain_mismatch' };

  for (const prev of seen) {
    if (querySimilarity(trimmed, prev) >= 0.9) return { valid: false, reason: 'duplicate_query' };
  }

  return { valid: true };
}

export function sanitizeExpansionPlan(raw: NicheExpansionPlan): NicheExpansionPlan {
  const subtopics = [...new Set(raw.subtopics.map((s) => s.trim()).filter(Boolean))].slice(0, 10);
  const exclusions = [...new Set(raw.exclusions.map((s) => s.trim()).filter(Boolean))].slice(0, 20);
  const validQueries: string[] = [];

  for (const q of raw.queries) {
    const check = validateExpansionQuery(q, raw.niche, subtopics.length ? subtopics : [raw.niche], validQueries);
    if (check.valid) validQueries.push(q.trim());
  }

  const queries = validQueries.length >= 4
    ? validQueries.slice(0, 15)
    : buildFallbackQueries(raw.niche);

  return {
    niche: raw.niche,
    domain: raw.domain.trim() || raw.niche,
    confidence: Math.max(0, Math.min(1, raw.confidence)),
    subtopics: subtopics.length ? subtopics : [raw.niche],
    queries,
    exclusions: exclusions.length ? exclusions : buildFallbackExpansionPlan(raw.niche).exclusions,
    version: NICHE_EXPANSION_PLAN_VERSION,
    generatedAt: new Date(),
  };
}

function rowToPlan(row: {
  niche: string;
  domain: string;
  confidence: number;
  subtopics: unknown;
  queries: unknown;
  exclusions: unknown;
  version: number;
  generatedAt: Date;
}): NicheExpansionPlan {
  return {
    niche: row.niche,
    domain: row.domain,
    confidence: row.confidence,
    subtopics: Array.isArray(row.subtopics) ? (row.subtopics as string[]) : [],
    queries: Array.isArray(row.queries) ? (row.queries as string[]) : [],
    exclusions: Array.isArray(row.exclusions) ? (row.exclusions as string[]) : [],
    version: row.version,
    generatedAt: row.generatedAt,
  };
}

export class NicheExpansionService {
  private openai: OpenAI | null;

  constructor(openaiApiKey?: string | null) {
    const key = openaiApiKey || process.env.OPENAI_API_KEY;
    this.openai = key ? new OpenAI({ apiKey: key }) : null;
  }

  async generatePlanWithAI(niche: string): Promise<NicheExpansionPlan> {
    if (!this.openai) return buildFallbackExpansionPlan(niche);

    try {
      const response = await this.openai.chat.completions.create({
        model: process.env.OPENAI_CONTENT_MODEL || 'gpt-4o-mini',
        temperature: 0.3,
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'niche_expansion_plan',
            strict: true,
            schema: NICHE_EXPANSION_OPENAI_SCHEMA,
          },
        },
        messages: [
          { role: 'system', content: NICHE_EXPANSION_SYSTEM_PROMPT },
          {
            role: 'user',
            content: `Niche: "${niche}"

Return one domain, confidence 0-1, 4-8 subtopics, 6-12 diverse queries, and 5-15 exclusion patterns.`,
          },
        ],
      });

      const raw = response.choices[0].message.content || '';
      const parsed = nicheExpansionSchema.safeParse(JSON.parse(raw));
      if (!parsed.success) {
        console.warn('[niche-expansion] schema validation failed; using fallback', { niche });
        return buildFallbackExpansionPlan(niche);
      }

      return sanitizeExpansionPlan({ ...parsed.data, version: NICHE_EXPANSION_PLAN_VERSION, generatedAt: new Date() });
    } catch (err) {
      console.warn('[niche-expansion] OpenAI failed; using fallback', {
        niche,
        message: err instanceof Error ? err.message : String(err),
      });
      return buildFallbackExpansionPlan(niche);
    }
  }

  async getOrCreatePlan(userId: string, niche: string, forceRefresh = false): Promise<NicheExpansionPlan> {
    const key = normalizeNicheKey(niche);

    if (!forceRefresh) {
      const existing = await prisma.userNicheSearchPlan.findUnique({
        where: { userId_niche: { userId, niche: key } },
      });
      if (existing && existing.version === NICHE_EXPANSION_PLAN_VERSION) {
        return rowToPlan(existing);
      }
    }

    const plan = await this.generatePlanWithAI(niche);
    const sanitized = sanitizeExpansionPlan(plan);

    await prisma.userNicheSearchPlan.upsert({
      where: { userId_niche: { userId, niche: key } },
      create: {
        userId,
        niche: key,
        domain: sanitized.domain,
        confidence: sanitized.confidence,
        subtopics: sanitized.subtopics,
        queries: sanitized.queries,
        exclusions: sanitized.exclusions,
        version: NICHE_EXPANSION_PLAN_VERSION,
      },
      update: {
        domain: sanitized.domain,
        confidence: sanitized.confidence,
        subtopics: sanitized.subtopics,
        queries: sanitized.queries,
        exclusions: sanitized.exclusions,
        version: NICHE_EXPANSION_PLAN_VERSION,
        generatedAt: new Date(),
      },
    });

    return sanitized;
  }
}
